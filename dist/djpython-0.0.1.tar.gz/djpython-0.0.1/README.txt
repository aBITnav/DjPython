This is a simple remixing tool for python which can create fusion of two or more songs change its tempo,frequency etc 
